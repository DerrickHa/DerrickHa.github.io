function dirniagara()
{
    let road = document.querySelector("#road").value;
    let city = document.querySelector("#city").value;
    window.open("https://google.ca/maps/dir/" + road + ", " + city + "/Bayview+Secondary+School/")
}